import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CadastroAluno {
	static Scanner teclado = new Scanner(System.in);
	
	// Criando um mapa ordenado para armazenar rgm e disciplinas de cada aluno
	static Map < String, List<String> > alunos = new TreeMap<>();
    
	public static void main(String[] args) {
		
	    // Loop para cadastrar 60 alunos automaticamente 
	    for (int i = 1; i <= 60; i++) {
	    	// especificando que o RGM terá inicio 2023 + um número inteiro com quatro dígitos
	        String rgm = "2023" + String.format("%04d", i);
	        //     rgm = "2023" + 0001 ; rgm = 20230001
	        //     ...
	        //     rgm = "2023" + 0060 ; rgm = 20230060
	        List<String> disciplinas = Arrays.asList("Estrutura de Dados I", "Matemática Discreta", "Programação Orientada a Objetos");

	        // Adicionando o rgm e suas disciplinas ao mapa "alunos"
	        alunos.put(rgm, disciplinas);
	    }
	   
	    // Exibindo menu de opções 
        System.out.println("\tMENU:");
        System.out.println("1. Incluir aluno");
        System.out.println("2. Buscar aluno");
        System.out.println("3. Remover aluno");
        System.out.println("4. Mostrar todos os alunos");
        
        // Permintindo o usuário escolher o que deseja e assim char uma das funções definidas:
        int opcao;
        do {
            System.out.print("\nEscolha uma opção: ");
            opcao = teclado.nextInt();
            teclado.nextLine(); 
            
            switch (opcao) {
                case 1:
                    incluirAluno();
                    break;
                case 2:
                    buscarAluno();
                    break;
                case 3:
                    removerAluno();
                    break;
                case 4:
                    mostrarAlunos();
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
	
	public static void incluirAluno() {
        System.out.println("\nCADASTRANDO ALUNO:");

        // Perguntar ao usuário quantos alunos deseja incluir
        System.out.print("Quantos alunos deseja cadastrar? ");
        int tamanhoSala = teclado.nextInt();
        teclado.nextLine();        

        // Loop para fazer cadastro dos alunos
        for (int i = 0; i < tamanhoSala; i++) {
            System.out.printf("\nCadastro do aluno %d :", i + 1);

            // Solicitando RGM do aluno
            System.out.print("\nRGM: ");
            String rgm = teclado.nextLine();

            // Solicitando as disciplinas do aluno que serão armazenado em uma lista
            List<String> disciplinas = new ArrayList<>();

            // Loop adicionar as disciplinas do aluno a lista
            String resposta;
            do {
                System.out.print("Disciplina: ");
                String disciplina = teclado.nextLine();
                disciplinas.add(disciplina); // adicionando a disciplina a lista "disciplinas"

                System.out.print("Deseja colocar mais disciplina [S/N]? ");
                resposta = teclado.nextLine();
            } while (resposta.equalsIgnoreCase("S"));


            // Adicionando o RGM e a lista de disciplinas ao Mapa
            alunos.put(rgm, disciplinas);
        }
	}
	
	// 1. Mostre todos os aluno, e respectivas disciplinas, cadastrados

	public static void mostrarAlunos() {
        
        // Loop para retornar todos os alunos cadastrados no Mapa
        System.out.println("\nALUNOS CADASTRADOS:");         
        for (Map.Entry <String, List<String> > entradaMapa : alunos.entrySet()) {
            String rgm = entradaMapa.getKey(); // retornando a chave 
            List<String> disciplinas = entradaMapa.getValue(); // retornando os valores 
            
            // Mostrando os dados
            System.out.println("RGM: " + rgm);
            System.out.println("Disciplinas: " + disciplinas + "\n");
        }
	}
	
    // 2. Procure um aluno pelo RGM e mostrando seus dados, caso exista ou mensagem de "não existe"

	public static void buscarAluno() {
		
		// Condição para enquanto não for encontrado um aluno pedir novamente o rgm novamente
    	List<String> buscaAluno;
		do {
			// Solicitando o RGM que deseja buscar
            System.out.print("\nDigite o RGM do aluno que deseja buscar: ");
            String rgmBusca = teclado.nextLine();
            
            // Lista para armazer os valores do RGM informado
            buscaAluno = alunos.get(rgmBusca);
            
            // Condição para caso o rgm não seja encontrado
            if (buscaAluno != null) {
                System.out.println("RGM: " + rgmBusca);
                System.out.println("Disciplinas: " + buscaAluno);
            } else {
                System.out.printf("Aluno %s não encontrado. Tente novamente!\n", rgmBusca);
            }
    	}while(buscaAluno == null);
	}
	
    // 3. Remova um aluno pelo RGM

	public static void removerAluno() {
    	// Condição para enquanto não for encontrado um aluno pedir o rgm novamente
		List<String> remocaoAluno;
        do {
        	// Solicitando o RGM que deseja remover
            System.out.print("\nDigite o RGM do aluno que deseja remover: ");
            String rgmRemocao = teclado.nextLine();
            
            // Lista para armazenar os valores do RGM informado
            remocaoAluno = alunos.remove(rgmRemocao);
            
            // Condição para caso o rgm não seja encontrado
            if (remocaoAluno != null) {
                System.out.printf("Aluno %s removido com sucesso.\n", rgmRemocao);
            } else {
                System.out.printf("Aluno %s não encontrado. Tente novamente!\n", rgmRemocao);
            }
        }while(remocaoAluno == null);
	}	
}
